import type { Metadata } from "next";
import "./globals.css";

export const metadata: Metadata = {
  title: "HandleHunt — Find Rare Instagram Usernames",
  description:
    "Scan and discover available 3-character and 4-character Instagram usernames. Session-based scanning with auto-saved progress. Built for serious username hunters.",
  keywords: [
    "instagram username",
    "available username",
    "3 letter instagram",
    "4 letter instagram",
    "rare handles",
    "instagram handle checker",
    "username finder",
  ],
  authors: [{ name: "HandleHunt" }],
  openGraph: {
    title: "HandleHunt — Find Rare Instagram Usernames",
    description:
      "Discover available 3 & 4 character Instagram usernames. Progress auto-saves. Resume anytime.",
    type: "website",
    siteName: "HandleHunt",
  },
  twitter: {
    card: "summary_large_image",
    title: "HandleHunt — Find Rare Instagram Usernames",
    description: "Scan 3 & 4 character Instagram handles. Session-based with auto-save.",
  },
  robots: {
    index: true,
    follow: true,
  },
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="en" className="dark">
      <body className="min-h-screen antialiased bg-[#050505] text-zinc-50 overflow-x-hidden">
        {children}
      </body>
    </html>
  );
}
