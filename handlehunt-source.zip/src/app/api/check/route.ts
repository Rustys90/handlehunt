import { NextRequest, NextResponse } from "next/server";

export const dynamic = "force-dynamic";

export async function GET(request: NextRequest) {
  const username = request.nextUrl.searchParams.get("username")?.toLowerCase().trim();

  if (!username) {
    return NextResponse.json({ error: "Username required" }, { status: 400 });
  }

  // Basic validation
  if (username.length < 1 || username.length > 30) {
    return NextResponse.json({
      status: "invalid",
      confidence: 0,
      message: "Username length must be 1-30 characters",
    });
  }

  try {
    // Public profile check — this is best-effort only
    // Instagram returns various responses for reserved / deactivated / banned names
    const controller = new AbortController();
    const timeout = setTimeout(() => controller.abort(), 8000);

    const res = await fetch(`https://www.instagram.com/${username}/`, {
      method: "GET",
      headers: {
        "User-Agent":
          "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36",
        Accept: "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8",
        "Accept-Language": "en-US,en;q=0.9",
      },
      signal: controller.signal,
      redirect: "follow",
    });

    clearTimeout(timeout);

    const text = await res.text();
    const lower = text.toLowerCase();

    // Heuristics for "no public profile"
    const noProfileSignals = [
      "sorry, this page isn't available",
      "page isn't available",
      "the link you followed may be broken",
      "profile isn't available",
      '"status":"fail"',
      "no content found",
    ];

    const hasProfileSignals = [
      `"username":"${username}"`,
      "profile_pic_url",
      "edge_followed_by",
      "og:title",
      "instagram.com/" + username,
    ];

    const looksMissing = noProfileSignals.some((s) => lower.includes(s));
    const looksPresent = hasProfileSignals.some((s) => lower.includes(s)) || res.status === 200 && text.length > 50000;

    if (looksMissing && !looksPresent) {
      return NextResponse.json({
        status: "available",
        confidence: 55,
        message: "No public profile found. This may be available — verify by trying to claim it in the Instagram app.",
      });
    }

    if (looksPresent) {
      return NextResponse.json({
        status: "taken",
        confidence: 85,
        message: "A public profile exists for this username.",
      });
    }

    // Ambiguous (login wall, private, reserved, etc.)
    return NextResponse.json({
      status: "unknown",
      confidence: 35,
      message: "Could not determine availability with high confidence. Instagram may be holding this name (deactivated, banned, or reserved).",
    });
  } catch (error: any) {
    if (error.name === "AbortError") {
      return NextResponse.json({
        status: "unknown",
        confidence: 20,
        message: "Request timed out. Try again.",
      });
    }
    return NextResponse.json({
      status: "unknown",
      confidence: 15,
      message: "Network error while checking. Please try again later.",
    });
  }
}
