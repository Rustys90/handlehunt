import { NextResponse } from "next/server";
import { createClient } from "@supabase/supabase-js";

export const dynamic = "force-dynamic";

const supabaseUrl = process.env.NEXT_PUBLIC_SUPABASE_URL || "https://tlsythdyjsvpehcvgwoc.supabase.co";
const supabaseKey = process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY || "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6InRsc3l0aGR5anN2cGVoY3Znd29jIiwicm9sZSI6ImFub24iLCJpYXQiOjE3ODY0OTIxMDIsImV4cCI6MjEwMjA2ODEwMn0.ib7YFAyFs0oqMo_RTrxvhhfy6kDu1-Ri8jLi0dfhC6o";

export async function GET() {
  try {
    const supabase = createClient(supabaseUrl, supabaseKey);

    const { data, error } = await supabase
      .from("available_usernames")
      .select("username, length, confidence, estimated_value, last_checked_at, status")
      .eq("status", "possibly_available")
      .order("last_checked_at", { ascending: false })
      .limit(50);

    if (error) {
      console.error("Supabase error:", error);
      return NextResponse.json({
        results: [],
        message: "Could not load results from database.",
        updatedAt: new Date().toISOString(),
      });
    }

    return NextResponse.json({
      results: data || [],
      message: data && data.length > 0 ? null : "No results yet. Start the worker to begin finding usernames.",
      updatedAt: new Date().toISOString(),
    });
  } catch (err) {
    return NextResponse.json({
      results: [],
      message: "Database connection error.",
      updatedAt: new Date().toISOString(),
    });
  }
}
