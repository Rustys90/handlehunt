import { NextRequest, NextResponse } from "next/server";
import { createClient } from "@supabase/supabase-js";

export const dynamic = "force-dynamic";

const supabaseUrl = process.env.NEXT_PUBLIC_SUPABASE_URL || "https://tlsythdyjsvpehcvgwoc.supabase.co";
const supabaseKey = process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY || "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6InRsc3l0aGR5anN2cGVoY3Znd29jIiwicm9sZSI6ImFub24iLCJpYXQiOjE3ODY0OTIxMDIsImV4cCI6MjEwMjA2ODEwMn0.ib7YFAyFs0oqMo_RTrxvhhfy6kDu1-Ri8jLi0dfhC6o";

export async function POST(request: NextRequest) {
  const body = await request.json();
  const { username, length, confidence, project_id } = body;

  if (!username) {
    return NextResponse.json({ error: "username required" }, { status: 400 });
  }

  const supabase = createClient(supabaseUrl, supabaseKey);

  const { error } = await supabase.from("available_usernames").upsert(
    {
      username,
      length: length || username.length,
      confidence: confidence || 50,
      status: "possibly_available",
      project_id: project_id || null,
      estimated_value: username.length === 3 ? "$1,000 – $15,000+" : "$200 – $5,000",
      source: "session",
      last_checked_at: new Date().toISOString(),
    },
    { onConflict: "username" }
  );

  if (error) {
    return NextResponse.json({ error: error.message }, { status: 500 });
  }

  return NextResponse.json({ ok: true });
}
