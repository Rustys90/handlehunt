import { NextRequest, NextResponse } from "next/server";
import { createClient } from "@supabase/supabase-js";

export const dynamic = "force-dynamic";

const supabaseUrl = process.env.NEXT_PUBLIC_SUPABASE_URL || "https://tlsythdyjsvpehcvgwoc.supabase.co";
const supabaseKey = process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY || "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6InRsc3l0aGR5anN2cGVoY3Znd29jIiwicm9sZSI6ImFub24iLCJpYXQiOjE3ODY0OTIxMDIsImV4cCI6MjEwMjA2ODEwMn0.ib7YFAyFs0oqMo_RTrxvhhfy6kDu1-Ri8jLi0dfhC6o";

export async function POST(request: NextRequest) {
  const body = await request.json();
  const { project_id, current_index, total_checked, found_count, last_username, status } = body;

  if (!project_id) {
    return NextResponse.json({ error: "project_id required" }, { status: 400 });
  }

  const supabase = createClient(supabaseUrl, supabaseKey);

  const { error } = await supabase
    .from("scan_projects")
    .update({
      current_index,
      total_checked,
      found_count,
      last_username,
      status: status || "paused",
      updated_at: new Date().toISOString(),
    })
    .eq("id", project_id);

  if (error) {
    return NextResponse.json({ error: error.message }, { status: 500 });
  }

  return NextResponse.json({ ok: true });
}
