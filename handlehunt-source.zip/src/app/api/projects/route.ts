import { NextRequest, NextResponse } from "next/server";
import { createClient } from "@supabase/supabase-js";

export const dynamic = "force-dynamic";

const supabaseUrl = process.env.NEXT_PUBLIC_SUPABASE_URL || "https://tlsythdyjsvpehcvgwoc.supabase.co";
const supabaseKey = process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY || "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6InRsc3l0aGR5anN2cGVoY3Znd29jIiwicm9sZSI6ImFub24iLCJpYXQiOjE3ODY0OTIxMDIsImV4cCI6MjEwMjA2ODEwMn0.ib7YFAyFs0oqMo_RTrxvhhfy6kDu1-Ri8jLi0dfhC6o";

export async function GET() {
  const supabase = createClient(supabaseUrl, supabaseKey);

  const { data, error } = await supabase
    .from("scan_projects")
    .select("*")
    .order("updated_at", { ascending: false });

  if (error) {
    return NextResponse.json({ projects: [], error: error.message });
  }

  return NextResponse.json({ projects: data || [] });
}

export async function POST(request: NextRequest) {
  const body = await request.json();
  const { length, name } = body;

  if (![3, 4].includes(length)) {
    return NextResponse.json({ error: "Length must be 3 or 4" }, { status: 400 });
  }

  const supabase = createClient(supabaseUrl, supabaseKey);

  const { data, error } = await supabase
    .from("scan_projects")
    .insert({
      name: name || `${length}-character scan`,
      length,
      status: "idle",
    })
    .select()
    .single();

  if (error) {
    return NextResponse.json({ error: error.message }, { status: 500 });
  }

  return NextResponse.json({ project: data });
}
