import Link from "next/link";
import { FolderOpen, Plus, ArrowRight } from "lucide-react";

export default function DashboardPage() {
  return (
    <div className="min-h-screen bg-zinc-950">
      <header className="border-b border-zinc-900">
        <div className="max-w-5xl mx-auto px-6 h-16 flex items-center justify-between">
          <Link href="/" className="flex items-center gap-2.5">
            <div className="w-8 h-8 rounded-lg bg-emerald-500 flex items-center justify-center">
              <span className="text-emerald-950 font-bold text-sm">H</span>
            </div>
            <span className="font-semibold tracking-tight text-lg">HandleHunt</span>
          </Link>
          <nav className="flex items-center gap-4 text-sm text-zinc-400">
            <Link href="/" className="hover:text-zinc-200 transition-colors">Home</Link>
            <Link href="/dashboard/projects" className="text-zinc-100">Projects</Link>
          </nav>
        </div>
      </header>

      <main className="max-w-5xl mx-auto px-6 py-16">
        <h1 className="text-3xl font-semibold tracking-tight mb-2">Dashboard</h1>
        <p className="text-zinc-400 mb-10">Your saved username scans and projects.</p>

        <div className="grid sm:grid-cols-2 gap-6">
          <Link
            href="/dashboard/projects"
            className="group p-6 rounded-2xl border border-zinc-800 bg-zinc-900/40 hover:border-zinc-700 transition-colors"
          >
            <div className="w-11 h-11 rounded-xl bg-zinc-800 flex items-center justify-center mb-4 group-hover:bg-zinc-700 transition-colors">
              <FolderOpen className="w-5 h-5 text-emerald-400" />
            </div>
            <h2 className="font-medium text-lg mb-1 flex items-center gap-2">
              Projects
              <ArrowRight className="w-4 h-4 opacity-0 group-hover:opacity-100 transition-opacity" />
            </h2>
            <p className="text-sm text-zinc-500">
              View and resume your saved 3-character and 4-character scan projects.
            </p>
          </Link>

          <Link
            href="/#checker"
            className="group p-6 rounded-2xl border border-zinc-800 bg-zinc-900/40 hover:border-zinc-700 transition-colors"
          >
            <div className="w-11 h-11 rounded-xl bg-zinc-800 flex items-center justify-center mb-4 group-hover:bg-zinc-700 transition-colors">
              <Plus className="w-5 h-5 text-emerald-400" />
            </div>
            <h2 className="font-medium text-lg mb-1 flex items-center gap-2">
              New Scan
              <ArrowRight className="w-4 h-4 opacity-0 group-hover:opacity-100 transition-opacity" />
            </h2>
            <p className="text-sm text-zinc-500">
              Start a new 3 or 4 character username scan. Progress saves automatically.
            </p>
          </Link>
        </div>
      </main>
    </div>
  );
}
