"use client";

import { useEffect, useState } from "react";
import Link from "next/link";
import { FolderOpen, Play, Clock, Hash } from "lucide-react";

type Project = {
  id: string;
  name: string;
  length: number;
  total_checked: number;
  found_count: number;
  status: string;
  last_username: string | null;
  updated_at: string;
  created_at: string;
};

export default function ProjectsPage() {
  const [projects, setProjects] = useState<Project[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    async function load() {
      try {
        const res = await fetch("/api/projects");
        const data = await res.json();
        setProjects(data.projects || []);
      } catch {
        setProjects([]);
      } finally {
        setLoading(false);
      }
    }
    load();
  }, []);

  return (
    <div className="min-h-screen bg-zinc-950">
      <header className="border-b border-zinc-900">
        <div className="max-w-5xl mx-auto px-6 h-16 flex items-center justify-between">
          <Link href="/" className="flex items-center gap-2.5">
            <div className="w-8 h-8 rounded-lg bg-emerald-500 flex items-center justify-center">
              <span className="text-emerald-950 font-bold text-sm">H</span>
            </div>
            <span className="font-semibold tracking-tight text-lg">HandleHunt</span>
          </Link>
          <nav className="flex items-center gap-4 text-sm text-zinc-400">
            <Link href="/dashboard" className="hover:text-zinc-200 transition-colors">Dashboard</Link>
            <Link href="/" className="hover:text-zinc-200 transition-colors">Home</Link>
          </nav>
        </div>
      </header>

      <main className="max-w-5xl mx-auto px-6 py-12">
        <div className="flex items-center justify-between mb-8">
          <div>
            <h1 className="text-2xl font-semibold tracking-tight">Projects</h1>
            <p className="text-zinc-400 text-sm mt-1">Saved scans. Resume anytime.</p>
          </div>
          <Link
            href="/#checker"
            className="px-4 py-2 rounded-xl bg-emerald-500 text-emerald-950 text-sm font-medium hover:bg-emerald-400 transition-colors"
          >
            New Scan
          </Link>
        </div>

        {loading ? (
          <div className="text-zinc-500 text-sm">Loading projects…</div>
        ) : projects.length === 0 ? (
          <div className="rounded-2xl border border-zinc-800 bg-zinc-900/40 p-12 text-center">
            <FolderOpen className="w-10 h-10 text-zinc-600 mx-auto mb-4" />
            <p className="text-zinc-400 mb-2">No projects yet</p>
            <p className="text-sm text-zinc-600 mb-6">
              Start a 3 or 4 character scan on the home page. Progress is saved automatically.
            </p>
            <Link
              href="/"
              className="inline-flex items-center gap-2 px-4 py-2 rounded-xl bg-zinc-800 text-sm hover:bg-zinc-700 transition-colors"
            >
              Go to scanner
            </Link>
          </div>
        ) : (
          <div className="space-y-3">
            {projects.map((p) => (
              <div
                key={p.id}
                className="flex items-center justify-between p-5 rounded-2xl border border-zinc-800 bg-zinc-900/40 hover:border-zinc-700 transition-colors"
              >
                <div className="flex items-start gap-4">
                  <div className="w-10 h-10 rounded-xl bg-zinc-800 flex items-center justify-center mt-0.5">
                    <Hash className="w-5 h-5 text-emerald-400" />
                  </div>
                  <div>
                    <h3 className="font-medium">{p.name || `${p.length}-character scan`}</h3>
                    <div className="flex items-center gap-4 mt-1.5 text-xs text-zinc-500">
                      <span>{p.length} chars</span>
                      <span>{p.total_checked.toLocaleString()} checked</span>
                      <span className="text-emerald-400/80">{p.found_count} found</span>
                      <span className="flex items-center gap-1">
                        <Clock className="w-3 h-3" />
                        {new Date(p.updated_at).toLocaleDateString()}
                      </span>
                    </div>
                  </div>
                </div>
                <Link
                  href={`/?resume=${p.id}`}
                  className="flex items-center gap-2 px-3 py-1.5 rounded-lg bg-zinc-800 text-sm hover:bg-zinc-700 transition-colors"
                >
                  <Play className="w-3.5 h-3.5" />
                  Resume
                </Link>
              </div>
            ))}
          </div>
        )}
      </main>
    </div>
  );
}
