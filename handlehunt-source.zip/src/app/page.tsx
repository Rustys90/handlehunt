"use client";

import Link from "next/link";
import { motion } from "framer-motion";
import Checker from "@/components/Checker";
import SessionScanner from "@/components/SessionScanner";
import LiveResults from "@/components/LiveResults";
import {
  Search,
  Shield,
  Zap,
  AlertCircle,
  FolderOpen,
  ArrowRight,
} from "lucide-react";

const fadeUp = {
  hidden: { opacity: 0, y: 24 },
  visible: (i: number) => ({
    opacity: 1,
    y: 0,
    transition: {
      delay: i * 0.08,
      duration: 0.55,
      ease: [0.22, 1, 0.36, 1],
    },
  }),
};

export default function Home() {
  return (
    <div className="min-h-screen relative">
      {/* Ambient background */}
      <div className="fixed inset-0 bg-grid pointer-events-none opacity-40" />
      <div className="glow-orb w-[500px] h-[500px] bg-emerald-500/20 -top-40 -left-40" />
      <div className="glow-orb w-[400px] h-[400px] bg-teal-600/10 top-1/3 -right-32" />

      {/* Header */}
      <header className="relative z-20 border-b border-white/[0.06] backdrop-blur-md bg-[#050505]/80 sticky top-0">
        <div className="max-w-5xl mx-auto px-6 h-16 flex items-center justify-between">
          <Link href="/" className="flex items-center gap-2.5 group">
            <div className="w-8 h-8 rounded-lg bg-emerald-500 flex items-center justify-center shadow-lg shadow-emerald-500/20 group-hover:shadow-emerald-500/40 transition-shadow">
              <Search className="w-4 h-4 text-emerald-950" />
            </div>
            <span className="font-semibold tracking-tight text-lg">HandleHunt</span>
          </Link>
          <nav className="flex items-center gap-5 text-sm text-zinc-400">
            <Link
              href="/dashboard"
              className="hover:text-zinc-100 transition-colors flex items-center gap-1.5"
            >
              <FolderOpen className="w-4 h-4" />
              <span className="hidden sm:inline">Dashboard</span>
            </Link>
            <a
              href="#how"
              className="hover:text-zinc-100 transition-colors hidden sm:inline"
            >
              How it works
            </a>
          </nav>
        </div>
      </header>

      <main className="relative z-10 max-w-5xl mx-auto px-6 pt-20 pb-28">
        {/* Hero */}
        <div className="text-center mb-16">
          <motion.div
            custom={0}
            initial="hidden"
            animate="visible"
            variants={fadeUp}
            className="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-full bg-white/[0.03] border border-white/[0.08] text-xs text-zinc-400 mb-8"
          >
            <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-pulse-soft" />
            Session-based · a–z + 0–9 · Auto-saved
          </motion.div>

          <motion.h1
            custom={1}
            initial="hidden"
            animate="visible"
            variants={fadeUp}
            className="text-4xl sm:text-6xl font-semibold tracking-tight text-zinc-50 mb-6 leading-[1.1]"
          >
            Find rare Instagram
            <br />
            <span className="bg-gradient-to-r from-emerald-400 via-teal-300 to-emerald-500 bg-clip-text text-transparent">
              usernames
            </span>
          </motion.h1>

          <motion.p
            custom={2}
            initial="hidden"
            animate="visible"
            variants={fadeUp}
            className="text-lg text-zinc-400 max-w-lg mx-auto leading-relaxed"
          >
            Scan 3 & 4 character handles while you’re here.
            Close the tab — progress is saved. Resume anytime from the Dashboard.
          </motion.p>
        </div>

        {/* Checker */}
        <motion.div
          custom={3}
          initial="hidden"
          animate="visible"
          variants={fadeUp}
          id="checker"
        >
          <Checker />
        </motion.div>

        {/* Session scanner */}
        <motion.div
          custom={4}
          initial="hidden"
          animate="visible"
          variants={fadeUp}
        >
          <SessionScanner />
        </motion.div>

        {/* Live results */}
        <motion.div
          custom={5}
          initial="hidden"
          whileInView="visible"
          viewport={{ once: true, margin: "-80px" }}
          variants={fadeUp}
        >
          <LiveResults />
        </motion.div>

        {/* Features */}
        <section className="mt-32 grid sm:grid-cols-3 gap-5">
          {[
            {
              icon: Zap,
              title: "Runs only while you’re here",
              body: "Scanning starts when you click Start and stops the moment you leave the page.",
            },
            {
              icon: FolderOpen,
              title: "Auto-saved projects",
              body: "Progress and found names land in Dashboard → Projects so you can resume later.",
            },
            {
              icon: Shield,
              title: "Honest confidence",
              body: "We never claim 100% availability. Always verify inside the Instagram app.",
            },
          ].map((f, i) => (
            <motion.div
              key={f.title}
              custom={i}
              initial="hidden"
              whileInView="visible"
              viewport={{ once: true, margin: "-40px" }}
              variants={fadeUp}
              className="group p-6 rounded-2xl bg-white/[0.02] border border-white/[0.06] hover:border-white/[0.12] hover:bg-white/[0.04] transition-all duration-300"
            >
              <div className="w-10 h-10 rounded-xl bg-emerald-500/10 border border-emerald-500/20 flex items-center justify-center mb-4 group-hover:scale-105 transition-transform">
                <f.icon className="w-5 h-5 text-emerald-400" />
              </div>
              <h3 className="font-medium text-zinc-100 mb-2">{f.title}</h3>
              <p className="text-sm text-zinc-500 leading-relaxed">{f.body}</p>
            </motion.div>
          ))}
        </section>

        {/* How it works */}
        <section id="how" className="mt-32">
          <motion.h2
            initial="hidden"
            whileInView="visible"
            viewport={{ once: true }}
            variants={fadeUp}
            custom={0}
            className="text-2xl font-semibold tracking-tight mb-8"
          >
            How it works
          </motion.h2>
          <motion.div
            initial="hidden"
            whileInView="visible"
            viewport={{ once: true }}
            variants={fadeUp}
            custom={1}
            className="space-y-5 text-zinc-400 leading-relaxed max-w-2xl"
          >
            <p>
              Click <strong className="text-zinc-200">Start Scan</strong> to begin
              checking every 3 or 4 character combination (a–z + 0–9). The scan
              runs in your browser session only.
            </p>
            <p>
              Every few checks the progress is written to the database. Close the
              tab and everything is kept.
            </p>
            <p>
              Return later via{" "}
              <Link
                href="/dashboard/projects"
                className="text-emerald-400 hover:text-emerald-300 underline underline-offset-2"
              >
                Dashboard → Projects
              </Link>{" "}
              to see saved scans and resume where you left off.
            </p>
          </motion.div>
        </section>

        {/* CTA */}
        <motion.div
          initial="hidden"
          whileInView="visible"
          viewport={{ once: true }}
          variants={fadeUp}
          custom={0}
          className="mt-20 p-8 rounded-2xl border border-emerald-500/20 bg-emerald-500/[0.06] text-center"
        >
          <h3 className="text-xl font-medium mb-2">Ready to hunt?</h3>
          <p className="text-zinc-400 text-sm mb-6">
            Start a scan above or open your saved projects.
          </p>
          <div className="flex items-center justify-center gap-3">
            <a
              href="#checker"
              className="inline-flex items-center gap-2 px-5 py-2.5 rounded-xl bg-emerald-500 text-emerald-950 text-sm font-medium hover:bg-emerald-400 transition-colors"
            >
              Start scanning
              <ArrowRight className="w-4 h-4" />
            </a>
            <Link
              href="/dashboard"
              className="inline-flex items-center gap-2 px-5 py-2.5 rounded-xl bg-white/[0.06] border border-white/[0.08] text-sm hover:bg-white/[0.1] transition-colors"
            >
              Open Dashboard
            </Link>
          </div>
        </motion.div>

        {/* Limitations */}
        <section className="mt-16 p-6 rounded-2xl bg-amber-500/[0.04] border border-amber-500/15">
          <h2 className="text-base font-medium text-amber-200/90 mb-3 flex items-center gap-2">
            <AlertCircle className="w-4 h-4" />
            Important
          </h2>
          <ul className="space-y-2 text-sm text-zinc-500">
            <li>
              • “Possibly available” does not guarantee you can register the name.
            </li>
            <li>
              • Instagram holds many usernames that have no public profile.
            </li>
            <li>
              • Always do the final check inside the official Instagram app.
            </li>
          </ul>
        </section>
      </main>

      {/* Footer */}
      <footer className="relative z-10 border-t border-white/[0.06] py-10">
        <div className="max-w-5xl mx-auto px-6 flex flex-col sm:flex-row items-center justify-between gap-4 text-sm text-zinc-600">
          <p>HandleHunt · Session-based scanning with auto-save</p>
          <p>Not affiliated with Meta or Instagram</p>
        </div>
      </footer>
    </div>
  );
}
