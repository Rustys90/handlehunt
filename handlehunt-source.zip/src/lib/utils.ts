import { clsx, type ClassValue } from "clsx";
import { twMerge } from "tailwind-merge";

export function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs));
}

export function isValidInstagramUsername(username: string): boolean {
  if (!username || username.length < 1 || username.length > 30) return false;
  // Instagram allows letters, numbers, periods, underscores
  // Cannot start/end with period, no consecutive periods
  const regex = /^(?!.*\.\.)(?!\.)(?!.*\.$)[a-zA-Z0-9._]+$/;
  return regex.test(username);
}

export function estimateValue(length: number, isBrandable: boolean = false): string {
  if (length === 3) return "$1,000 – $15,000+";
  if (length === 4) return "$200 – $5,000";
  if (length === 5) return isBrandable ? "$100 – $2,000" : "$50 – $500";
  return "$50 – $800";
}
