import { createClient } from "@supabase/supabase-js";

const supabaseUrl = process.env.NEXT_PUBLIC_SUPABASE_URL || "https://tlsythdyjsvpehcvgwoc.supabase.co";
const supabaseAnonKey = process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY || "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6InRsc3l0aGR5anN2cGVoY3Znd29jIiwicm9sZSI6ImFub24iLCJpYXQiOjE3ODY0OTIxMDIsImV4cCI6MjEwMjA2ODEwMn0.ib7YFAyFs0oqMo_RTrxvhhfy6kDu1-Ri8jLi0dfhC6o";

export const supabase = createClient(supabaseUrl, supabaseAnonKey);
