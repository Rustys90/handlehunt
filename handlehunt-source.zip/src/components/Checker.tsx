"use client";

import { useState } from "react";
import { Search, Loader2, CheckCircle2, XCircle, AlertTriangle, Copy, ExternalLink } from "lucide-react";
import { cn, isValidInstagramUsername, estimateValue } from "@/lib/utils";

type CheckResult = {
  username: string;
  status: "available" | "taken" | "unknown" | "invalid";
  confidence: number;
  message: string;
  checkedAt: string;
};

export default function Checker() {
  const [input, setInput] = useState("");
  const [loading, setLoading] = useState(false);
  const [result, setResult] = useState<CheckResult | null>(null);
  const [recent, setRecent] = useState<CheckResult[]>([]);

  const checkUsername = async () => {
    const username = input.trim().toLowerCase().replace(/^@/, "");
    
    if (!username) return;
    
    if (!isValidInstagramUsername(username)) {
      setResult({
        username,
        status: "invalid",
        confidence: 0,
        message: "Invalid format. Use only letters, numbers, periods and underscores.",
        checkedAt: new Date().toISOString(),
      });
      return;
    }

    if (username.length < 3 || username.length > 4) {
      setResult({
        username,
        status: "invalid",
        confidence: 0,
        message: "This MVP currently focuses on 3 and 4 character usernames only.",
        checkedAt: new Date().toISOString(),
      });
      return;
    }

    setLoading(true);
    setResult(null);

    try {
      // Best-effort public profile check
      // Note: This is not 100% accurate. Instagram holds many names without public profiles.
      const res = await fetch(`/api/check?username=${encodeURIComponent(username)}`, {
        method: "GET",
        cache: "no-store",
      });

      const data = await res.json();

      const checkResult: CheckResult = {
        username,
        status: data.status || "unknown",
        confidence: data.confidence || 40,
        message: data.message || "Check completed",
        checkedAt: new Date().toISOString(),
      };

      setResult(checkResult);
      setRecent((prev) => [checkResult, ...prev].slice(0, 8));
    } catch (err) {
      setResult({
        username,
        status: "unknown",
        confidence: 20,
        message: "Unable to reach checking service. Try again later.",
        checkedAt: new Date().toISOString(),
      });
    } finally {
      setLoading(false);
    }
  };

  const handleKeyDown = (e: React.KeyboardEvent) => {
    if (e.key === "Enter") checkUsername();
  };

  return (
    <div className="w-full max-w-xl mx-auto">
      <div className="relative">
        <div className="flex items-center gap-2 bg-zinc-900/80 border border-zinc-800 rounded-2xl p-2 shadow-2xl shadow-black/40">
          <div className="flex items-center justify-center w-12 h-12 rounded-xl bg-zinc-800 text-zinc-400">
            <span className="text-lg font-medium">@</span>
          </div>
          <input
            type="text"
            value={input}
            onChange={(e) => setInput(e.target.value.toLowerCase())}
            onKeyDown={handleKeyDown}
            placeholder="Enter 3 or 4 character username"
            maxLength={4}
            className="flex-1 bg-transparent border-none outline-none text-lg text-zinc-100 placeholder:text-zinc-600 py-3 px-1"
            disabled={loading}
          />
          <button
            onClick={checkUsername}
            disabled={loading || !input.trim()}
            className={cn(
              "flex items-center justify-center gap-2 h-12 px-6 rounded-xl font-medium transition-all",
              loading || !input.trim()
                ? "bg-zinc-800 text-zinc-500 cursor-not-allowed"
                : "bg-emerald-500 hover:bg-emerald-400 text-emerald-950"
            )}
          >
            {loading ? (
              <Loader2 className="w-5 h-5 animate-spin" />
            ) : (
              <>
                <Search className="w-5 h-5" />
                <span className="hidden sm:inline">Check</span>
              </>
            )}
          </button>
        </div>
      </div>

      {result && (
        <div
          className={cn(
            "mt-6 rounded-2xl border p-5 transition-all",
            result.status === "available" && "bg-emerald-500/10 border-emerald-500/30",
            result.status === "taken" && "bg-red-500/10 border-red-500/30",
            result.status === "unknown" && "bg-amber-500/10 border-amber-500/30",
            result.status === "invalid" && "bg-zinc-800/50 border-zinc-700"
          )}
        >
          <div className="flex items-start justify-between gap-4">
            <div className="flex items-start gap-3">
              {result.status === "available" && <CheckCircle2 className="w-6 h-6 text-emerald-400 mt-0.5" />}
              {result.status === "taken" && <XCircle className="w-6 h-6 text-red-400 mt-0.5" />}
              {(result.status === "unknown" || result.status === "invalid") && (
                <AlertTriangle className="w-6 h-6 text-amber-400 mt-0.5" />
              )}
              <div>
                <p className="font-mono text-xl font-semibold tracking-tight">@{result.username}</p>
                <p className="text-sm text-zinc-400 mt-1">{result.message}</p>
                {result.status === "available" && (
                  <p className="text-sm text-emerald-400/80 mt-2">
                    Estimated value: {estimateValue(result.username.length)}
                  </p>
                )}
                <p className="text-xs text-zinc-600 mt-2">
                  Confidence: {result.confidence}% · Always verify in the Instagram app
                </p>
              </div>
            </div>
            {result.status === "available" && (
              <div className="flex gap-2">
                <button
                  onClick={() => navigator.clipboard.writeText(result.username)}
                  className="p-2 rounded-lg bg-zinc-800 hover:bg-zinc-700 text-zinc-300"
                  title="Copy"
                >
                  <Copy className="w-4 h-4" />
                </button>
                <a
                  href={`https://www.instagram.com/${result.username}`}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="p-2 rounded-lg bg-zinc-800 hover:bg-zinc-700 text-zinc-300"
                  title="Open on Instagram"
                >
                  <ExternalLink className="w-4 h-4" />
                </a>
              </div>
            )}
          </div>
        </div>
      )}

      {recent.length > 0 && (
        <div className="mt-10">
          <h3 className="text-sm font-medium text-zinc-500 mb-3">Recent checks</h3>
          <div className="space-y-2">
            {recent.map((r, i) => (
              <div
                key={`${r.username}-${i}`}
                className="flex items-center justify-between py-2 px-3 rounded-lg bg-zinc-900/50 border border-zinc-800/50"
              >
                <span className="font-mono text-sm">@{r.username}</span>
                <span
                  className={cn(
                    "text-xs font-medium px-2 py-0.5 rounded-full",
                    r.status === "available" && "bg-emerald-500/20 text-emerald-400",
                    r.status === "taken" && "bg-red-500/20 text-red-400",
                    (r.status === "unknown" || r.status === "invalid") && "bg-zinc-700 text-zinc-400"
                  )}
                >
                  {r.status}
                </span>
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
}
