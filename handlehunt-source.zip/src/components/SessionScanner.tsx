"use client";

import { useState, useEffect, useRef, useCallback } from "react";
import { Play, Pause } from "lucide-react";
import { cn } from "@/lib/utils";

// a-z + 0-9 = 36 characters
const CHARSET = "abcdefghijklmnopqrstuvwxyz0123456789";
const BASE = CHARSET.length; // 36

function* generateFromIndex(length: number, startIndex: number) {
  const total = Math.pow(BASE, length);
  for (let i = startIndex; i < total; i++) {
    let n = i;
    let s = "";
    for (let j = 0; j < length; j++) {
      s = CHARSET[n % BASE] + s;
      n = Math.floor(n / BASE);
    }
    yield { username: s, index: i };
  }
}

function totalCombinations(length: number) {
  return Math.pow(BASE, length);
}

type Props = {
  initialLength?: 3 | 4;
  resumeProjectId?: string | null;
};

export default function SessionScanner({ initialLength = 3, resumeProjectId = null }: Props) {
  const [length, setLength] = useState<3 | 4>(initialLength);
  const [running, setRunning] = useState(false);
  const [projectId, setProjectId] = useState<string | null>(resumeProjectId);
  const [checked, setChecked] = useState(0);
  const [found, setFound] = useState(0);
  const [current, setCurrent] = useState("");
  const [foundList, setFoundList] = useState<string[]>([]);
  const [status, setStatus] = useState("Ready");

  const runningRef = useRef(false);
  const indexRef = useRef(0);
  const abortRef = useRef(false);

  const saveProgress = useCallback(
    async (
      pid: string,
      idx: number,
      totalChecked: number,
      foundCount: number,
      lastUser: string
    ) => {
      try {
        await fetch("/api/projects/progress", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({
            project_id: pid,
            current_index: idx,
            total_checked: totalChecked,
            found_count: foundCount,
            last_username: lastUser,
            status: runningRef.current ? "running" : "paused",
          }),
        });
      } catch {}
    },
    []
  );

  const checkOne = async (
    username: string
  ): Promise<"available" | "taken" | "unknown"> => {
    try {
      const res = await fetch(
        `/api/check?username=${encodeURIComponent(username)}`
      );
      const data = await res.json();
      return data.status === "available"
        ? "available"
        : data.status === "taken"
          ? "taken"
          : "unknown";
    } catch {
      return "unknown";
    }
  };

  const startScan = async () => {
    abortRef.current = false;
    runningRef.current = true;
    setRunning(true);
    setStatus("Running…");

    let pid = projectId;

    if (!pid) {
      const res = await fetch("/api/projects", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          length,
          name: `${length}-char (a-z + 0-9)`,
        }),
      });
      const data = await res.json();
      if (data.project) {
        pid = data.project.id;
        setProjectId(pid);
        indexRef.current = 0;
      }
    }

    if (!pid) {
      setStatus("Failed to create project");
      setRunning(false);
      runningRef.current = false;
      return;
    }

    const gen = generateFromIndex(length, indexRef.current);
    let localChecked = checked;
    let localFound = found;
    let lastSave = Date.now();
    const total = totalCombinations(length);

    for (const { username, index } of gen) {
      if (abortRef.current) break;

      setCurrent(username);
      indexRef.current = index;

      const result = await checkOne(username);
      localChecked++;
      setChecked(localChecked);

      if (result === "available") {
        localFound++;
        setFound(localFound);
        setFoundList((prev) => [username, ...prev].slice(0, 30));

        try {
          await fetch("/api/results/save", {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({
              username,
              length,
              confidence: 55,
              project_id: pid,
            }),
          });
        } catch {}
      }

      // Save progress every 10 checks or every 15 seconds
      if (localChecked % 10 === 0 || Date.now() - lastSave > 15000) {
        await saveProgress(pid, index, localChecked, localFound, username);
        lastSave = Date.now();
        setStatus(
          `Running… ${localChecked.toLocaleString()} / ${total.toLocaleString()}`
        );
      }

      // Respectful delay
      await new Promise((r) => setTimeout(r, 1200));
    }

    runningRef.current = false;
    setRunning(false);
    setStatus(abortRef.current ? "Paused — progress saved" : "Completed");
    if (pid) {
      await saveProgress(
        pid,
        indexRef.current,
        localChecked,
        localFound,
        current
      );
    }
  };

  const stopScan = () => {
    abortRef.current = true;
    runningRef.current = false;
    setRunning(false);
    setStatus("Paused — progress saved");
  };

  // Stop when user leaves the page
  useEffect(() => {
    const handleUnload = () => {
      abortRef.current = true;
      runningRef.current = false;
    };
    window.addEventListener("beforeunload", handleUnload);
    return () => {
      window.removeEventListener("beforeunload", handleUnload);
      abortRef.current = true;
      runningRef.current = false;
    };
  }, []);

  return (
    <div className="w-full max-w-xl mx-auto mt-10">
      <div className="rounded-2xl border border-zinc-800 bg-zinc-900/50 p-6">
        <div className="flex items-center justify-between mb-6">
          <h3 className="font-medium">Session Scanner</h3>
          <div className="flex gap-2">
            <button
              onClick={() => !running && setLength(3)}
              className={cn(
                "px-3 py-1 rounded-lg text-sm",
                length === 3
                  ? "bg-emerald-500/20 text-emerald-400"
                  : "bg-zinc-800 text-zinc-400"
              )}
            >
              3 char
            </button>
            <button
              onClick={() => !running && setLength(4)}
              className={cn(
                "px-3 py-1 rounded-lg text-sm",
                length === 4
                  ? "bg-emerald-500/20 text-emerald-400"
                  : "bg-zinc-800 text-zinc-400"
              )}
            >
              4 char
            </button>
          </div>
        </div>

        <p className="text-xs text-zinc-500 mb-5">
          Charset: <span className="font-mono text-zinc-400">a–z + 0–9</span>{" "}
          ({totalCombinations(length).toLocaleString()} total combinations)
        </p>

        <div className="grid grid-cols-3 gap-4 mb-6 text-center">
          <div>
            <p className="text-2xl font-semibold tabular-nums">{checked}</p>
            <p className="text-xs text-zinc-500">Checked</p>
          </div>
          <div>
            <p className="text-2xl font-semibold tabular-nums text-emerald-400">
              {found}
            </p>
            <p className="text-xs text-zinc-500">Found</p>
          </div>
          <div>
            <p className="text-sm font-mono text-zinc-300 truncate">
              {current || "—"}
            </p>
            <p className="text-xs text-zinc-500">Current</p>
          </div>
        </div>

        <div className="flex gap-3">
          {!running ? (
            <button
              onClick={startScan}
              className="flex-1 flex items-center justify-center gap-2 h-11 rounded-xl bg-emerald-500 text-emerald-950 font-medium hover:bg-emerald-400 transition-colors"
            >
              <Play className="w-4 h-4" />
              {projectId ? "Resume Scan" : "Start Scan"}
            </button>
          ) : (
            <button
              onClick={stopScan}
              className="flex-1 flex items-center justify-center gap-2 h-11 rounded-xl bg-zinc-800 text-zinc-200 font-medium hover:bg-zinc-700 transition-colors"
            >
              <Pause className="w-4 h-4" />
              Pause & Save
            </button>
          )}
        </div>

        <p className="text-xs text-zinc-500 mt-4 text-center">{status}</p>
        <p className="text-xs text-zinc-600 mt-1 text-center">
          Runs only while this page is open. Progress is saved automatically.
        </p>

        {foundList.length > 0 && (
          <div className="mt-6 pt-5 border-t border-zinc-800">
            <p className="text-xs text-zinc-500 mb-2">Recently found</p>
            <div className="flex flex-wrap gap-2">
              {foundList.map((u) => (
                <span
                  key={u}
                  className="px-2 py-1 rounded-md bg-emerald-500/10 text-emerald-400 text-xs font-mono"
                >
                  @{u}
                </span>
              ))}
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
