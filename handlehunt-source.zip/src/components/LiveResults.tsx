"use client";

import { useEffect, useState } from "react";
import { RefreshCw, Database } from "lucide-react";

type Result = {
  username: string;
  length: number;
  confidence: number;
  estimated_value?: string;
  last_checked_at?: string;
};

export default function LiveResults() {
  const [results, setResults] = useState<Result[]>([]);
  const [loading, setLoading] = useState(true);
  const [message, setMessage] = useState("");
  const [lastUpdate, setLastUpdate] = useState<string | null>(null);

  const fetchResults = async () => {
    setLoading(true);
    try {
      const res = await fetch("/api/results", { cache: "no-store" });
      const data = await res.json();
      setResults(data.results || []);
      setMessage(data.message || "");
      setLastUpdate(data.updatedAt || new Date().toISOString());
    } catch {
      setMessage("Failed to load results");
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchResults();
    const interval = setInterval(fetchResults, 60000); // refresh every 60s
    return () => clearInterval(interval);
  }, []);

  return (
    <section className="mt-20">
      <div className="flex items-center justify-between mb-6">
        <div className="flex items-center gap-2">
          <Database className="w-5 h-5 text-emerald-400" />
          <h2 className="text-xl font-semibold tracking-tight">Live Finds</h2>
        </div>
        <button
          onClick={fetchResults}
          disabled={loading}
          className="flex items-center gap-2 text-sm text-zinc-400 hover:text-zinc-200 transition-colors"
        >
          <RefreshCw className={`w-4 h-4 ${loading ? "animate-spin" : ""}`} />
          Refresh
        </button>
      </div>

      {results.length === 0 ? (
        <div className="rounded-2xl border border-zinc-800 bg-zinc-900/40 p-8 text-center">
          <p className="text-zinc-400 text-sm leading-relaxed max-w-md mx-auto">
            {message || "No results yet. The continuous worker will populate this list once it is running and connected to the database."}
          </p>
          {lastUpdate && (
            <p className="text-xs text-zinc-600 mt-4">
              Last checked: {new Date(lastUpdate).toLocaleString()}
            </p>
          )}
        </div>
      ) : (
        <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-3">
          {results.map((r) => (
            <div
              key={r.username}
              className="flex items-center justify-between p-4 rounded-xl bg-zinc-900/60 border border-zinc-800"
            >
              <div>
                <p className="font-mono font-medium">@{r.username}</p>
                <p className="text-xs text-zinc-500 mt-0.5">
                  {r.length} chars · {r.confidence}% confidence
                </p>
              </div>
              <span className="text-xs text-emerald-400/80">
                {r.estimated_value || (r.length === 3 ? "$1k+" : "$200+")}
              </span>
            </div>
          ))}
        </div>
      )}
    </section>
  );
}
