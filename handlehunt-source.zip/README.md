# HandleHunt

Session-based Instagram username scanner for **3-character** and **4-character** handles.

## How it works

- Scanning runs **only while you are on the website**
- Progress and found usernames are **automatically saved** to Supabase
- When you close the tab → scanning stops
- When you return → open **Dashboard → Projects** to see saved scans and resume

## Architecture

```
Browser (Session Scanner)
        │
        ▼
   Next.js API routes
        │
        ▼
     Supabase (Postgres)
        │
        ▼
Dashboard → Projects (view & resume)
```

No 24/7 worker needed.

## Features

- On-demand single username check
- Session scanner (3 or 4 character)
- Auto-save progress every few checks
- Dashboard with saved projects
- Live results list

## Setup

```bash
npm install
npm run dev
```

Environment is already pointed at your Supabase project (`skillforge-v2`).

## Deploy to Vercel

```bash
npx vercel
```

Add the same env vars in the Vercel dashboard if needed:
- `NEXT_PUBLIC_SUPABASE_URL`
- `NEXT_PUBLIC_SUPABASE_ANON_KEY`

## Important

Results are “possibly available” only.  
Always verify by trying to claim the username inside the Instagram app.
